const ctx = document.getElementById('progressChart').getContext('2d');
const progressChart = new Chart(ctx, {
    type: 'bar',
    data: {
        labels: ['Organize', 'Cleanup'],
        datasets: [{
            label: 'Tasks Completed',
            data: [0, 0],
            backgroundColor: ['#007BFF', '#28A745']
        }]
    },
    options: {
        responsive: true,
        plugins: {
            legend: { position: 'top' }
        }
    }
});

async function runTask(task) {
    const response = await fetch(`/${task}`, { method: 'POST' });
    const result = await response.json();
    document.getElementById('status').innerText = result.message;

    // Update the chart dynamically
    if (task === 'organize') progressChart.data.datasets[0].data[0]++;
    if (task === 'cleanup') progressChart.data.datasets[0].data[1]++;
    progressChart.update();
}
