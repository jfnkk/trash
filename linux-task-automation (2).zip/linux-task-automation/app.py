from flask import Flask, jsonify
from scripts.file_organizer import organize_files
from scripts.system_cleanup import system_cleanup

# Initialize Flask app with 'static' folder for serving static files
app = Flask(__name__, static_folder='static')

# Route to serve the HTML page (index.html) from the 'static' folder
@app.route('/')
def index():
    return app.send_static_file('index.html')

# API endpoint for the 'organize' task
@app.route('/organize', methods=['POST'])
def organize():
    try:
        organize_files()  # Calls the organize_files function
        return jsonify({'status': 'success', 'message': 'Files organized successfully!'})
    except Exception as e:
        return jsonify({'status': 'error', 'message': str(e)}), 500

# API endpoint for the 'cleanup' task
@app.route('/cleanup', methods=['POST'])
def cleanup():
    try:
        system_cleanup()  # Calls the system_cleanup function
        return jsonify({'status': 'success', 'message': 'System cleanup completed!'})
    except Exception as e:
        return jsonify({'status': 'error', 'message': str(e)}), 500

if __name__ == '__main__':
    app.run(debug=True)
