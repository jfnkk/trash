import os
import shutil

def organize_files():
    DOWNLOADS_DIR = os.path.join(os.environ["USERPROFILE"], "Downloads")
    FILE_TYPES = {
        "Images": [".jpg", ".png", ".jpeg", ".gif"],
        "Documents": [".pdf", ".docx", ".txt"],
        "Videos": [".mp4", ".mkv"],
        "Others": []
    }

    for file in os.listdir(DOWNLOADS_DIR):
        file_path = os.path.join(DOWNLOADS_DIR, file)
        if os.path.isfile(file_path):
            for folder, extensions in FILE_TYPES.items():
                if file.endswith(tuple(extensions)):
                    folder_path = os.path.join(DOWNLOADS_DIR, folder)
                    os.makedirs(folder_path, exist_ok=True)
                    shutil.move(file_path, folder_path)
                    print(f"Moved {file} to {folder}")
                    break

if __name__ == "__main__":
    organize_files()
