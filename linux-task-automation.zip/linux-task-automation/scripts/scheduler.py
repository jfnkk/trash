import schedule
import time
from file_organizer import organize_files
from system_cleanup import system_cleanup

def schedule_tasks():
    schedule.every().day.at("08:00").do(organize_files)
    schedule.every().sunday.at("10:00").do(system_cleanup)

    while True:
        schedule.run_pending()
        time.sleep(1)

if __name__ == "__main__":
    schedule_tasks()
