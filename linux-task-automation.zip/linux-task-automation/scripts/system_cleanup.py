import os
import subprocess

def system_cleanup():
    print("Clearing temporary files...")
    temp_dir = os.environ["TEMP"]
    for root, dirs, files in os.walk(temp_dir):
        for file in files:
            try:
                os.remove(os.path.join(root, file))
            except Exception as e:
                print(f"Failed to delete {file}: {e}")

    print("Cleaning unnecessary files...")
    subprocess.run(["cleanmgr"], shell=True)

if __name__ == "__main__":
    system_cleanup()
